/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringapp;


/**
 *
 * @author Aidan Smith
 */
public class One {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println ("Problem 1A");
        StringReview.problem1 (args);
        System.out.println ();
        
        System.out.println ("Problem 1B");
        StringReview.problem2 (args);
        System.out.println ();
        
        System.out.println ("Problem 1C");
        StringReview.problem3 (args);
        System.out.println ();
        
        System.out.println ("Problem 1D");
        StringReview.problem4 (args);
        System.out.println ();
        
        System.out.println ("Problem 2");
        StringReview2.question2 (args);
        System.out.println ();
        
        System.out.println ("Problem 3");
        StringReview3.question3 (args);
        System.out.println ();
        
        System.out.println ("Problem 4");
        StringReview4.question4 (args);
        System.out.println ();
    }
    
}
